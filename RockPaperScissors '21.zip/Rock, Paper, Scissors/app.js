let userScore = 0;
let computerScore = 0;
const userScore_span = document.getElementById("user-score");
const computerScore_span = document.getElementById("computer-score");
const scoreBoard_div = document.querySelector(".score-board");
const result_p = document.querySelector(".result > p");
const rock_div = document.getElementById("r");
const paper_div = document.getElementById("p");
const scissors_div = document.getElementById("s");
const flintlock_div = document.getElementById("f");

//main body
main();

function main() {

	rock_div.addEventListener('click', function() {
		game("r");
	})

	paper_div.addEventListener('click', function() {
		game("p");
	})

	scissors_div.addEventListener('click', function() {
		game("s");
	})
	
	flintlock_div.addEventListener('click', function() {
		game("f");
	})
}

function win(userChoice, computerChoice){
	//console.log("USER WINS");
	userScore++;
	//console.log(userScore);
	userScore_span.innerHTML = userScore;
	result_p.innerHTML = convertWord(userChoice) + " beats " + convertWord(computerChoice) + ". You win!";
}

function lose(userChoice, computerChoice){
	//console.log("USER LOSES");
	computerScore++;
	//console.log(userScore);
	computerScore_span.innerHTML = computerScore;
	result_p.innerHTML = convertWord(userChoice) + " loses to " + convertWord(computerChoice) + ". You lose!";

}function win2(computerChoice, computerChoice2){
	//console.log("USER WINS");
	computerScore++;
	//console.log(userScore);
	userScore_span.innerHTML = userScore;
	result_p.innerHTML = convertWord(computerScore) + " beats " + convertWord(computerChoice) + ". You win!";
}

function lose2(computerChoice, computerChoice2){
	//console.log("USER LOSES");
	computerScore++;
	//console.log(userScore);
	computerScore_span.innerHTML = computerScore;
	result_p.innerHTML = convertWord(computerScore2) + " loses to " + convertWord(computerChoice) + ". You lose!";

}

function draw2(computerScore, computerChoice2){
	console.log("USER TIES");
	//userScore++;
	//console.log(userScore);
	userScore_span.innerHTML = computerScore;
	result_p.innerHTML = convertWord(computerScore) + " ties " + convertWord(computerChoice) + ". You tie!";

}

function draw(userChoice, computerChoice){
	console.log("USER TIES");
	//userScore++;
	//console.log(userScore);
	userScore_span.innerHTML = userScore;
	result_p.innerHTML = convertWord(userChoice) + " ties " + convertWord(computerChoice) + ". You tie!";

}

function convertWord (letter) {
	if (letter === "r") {return "Rock"};
	if (letter === "p") {return "Paper"};
	if (letter === "s") {return "Scissors"};
	if (letter === "f") {return "Flintlock"};
	const result = computerChoice + computerChoice;
}

function autogame(userChoice) {
	const computerChoice = getComputerChoice();
	const result == computerChoice + getComputerChoice;
	console.log(result);
	switch (result) {
		case "rs":
		case "pr":
		case "sp":
		case "fr":
		case "fp":
		case "fs"
			win(computerChoice, computerChoice);
			//console.log("USER WINS");
			break;
		case "rp":
		case "ps":
		case "sr":
		case "fr":
		
			lose(computerChoice, computerChoice);
			//console.log("USER LOSES");
			break;
		case "rr":
		case "pp":
		case "ss":
		case "ff":
			draw(computerChoice, computerChoice);
			//console.log("TIE");
			break;
	}
}

}

function game(userChoice) {
	const computerChoice = getComputerChoice();
	const result = userChoice + computerChoice;
	console.log(result);
	switch (result) {
		case "rs":
		case "pr":
		case "sp":
		case "fr":
		case "fp":
		case "fs":
			win(userChoice, computerChoice);
			//console.log("USER WINS");
			break;
		case "rp":
		case "ps":
		case "sr":
		case "fr":
		
			lose(userChoice, computerChoice);
			//console.log("USER LOSES");
			break;
		case "rr":
		case "pp":
		case "ss":
		case "ff":
			draw(userChoice, computerChoice);
			//console.log("TIE");
			break;
	}
}

function getComputerChoice() {
	const choices = ['r', 'p', 's', 'f'];
	var randNum = Math.floor(Math.random() * choices.length);
	return choices[randNum];
}